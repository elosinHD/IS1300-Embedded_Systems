#include <stdint.h>

void Pingpong(void);