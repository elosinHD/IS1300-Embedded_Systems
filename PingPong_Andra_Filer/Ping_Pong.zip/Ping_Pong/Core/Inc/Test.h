void Test_program(void);
void Test_Led(void);
void Test_Show_Points(uint8_t L_points, uint8_t R_points);
void Test_buttons(void);